"""
Offline smoke test: runs every page of the app against synthetic data and fails on any exception.
    python tests/smoke_test.py
"""
import os, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tests"))
import mock_network
mock_network.install()
from streamlit.testing.v1 import AppTest

APP = os.path.join(ROOT, "app.py")
PAGES = ["🏠 Market & FII Radar", "⭐ Watchlist & Pinned", "🔍 Search & Multi-TF Engine", "🎯 Stocks (High Conviction)",
         "💼 Mutual Funds (Ranked)", "🤖 AI Quant Copilot", "📰 News & Forex Factory"]

def check(at, label):
    if at.exception:
        print(f"  ✗ {label}")
        for e in at.exception:
            print("    ", str(e.value)[:600]); print("    ", "\n".join(e.stack_trace[-6:]) if e.stack_trace else "")
        return False
    print(f"  ✓ {label}")
    return True

ok = True
t0 = time.time()
at = AppTest.from_file(APP, default_timeout=240)
at.run(); ok &= check(at, f"cold start (Market page) [{time.time()-t0:.1f}s]")
for pg in PAGES[1:]:
    t = time.time()
    at.radio(key="nav").set_value(pg).run()
    ok &= check(at, f"{pg} [{time.time()-t:.1f}s]")
print("ALL OK" if ok else "FAILURES")
sys.exit(0 if ok else 1)
