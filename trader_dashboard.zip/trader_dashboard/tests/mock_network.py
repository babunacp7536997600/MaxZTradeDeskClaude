"""
Offline mocks used by tests/smoke_test.py - they replace every network call of data.py with deterministic
synthetic prices so the whole app can be exercised without internet.  NOT used by the real app.
"""
import hashlib
import json
import sys
import os

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import data as D  # noqa: E402
import yfinance as yf  # noqa: E402


def _seed(s):
    return int(hashlib.md5(s.encode()).hexdigest()[:8], 16)


def _daily(sym, n=780, start=None):
    rng = np.random.default_rng(_seed(sym))
    vol = 0.009 if sym.startswith("^") else rng.uniform(0.012, 0.026)
    drift = rng.uniform(-0.0004, 0.0012)
    phase = rng.uniform(0, 6)
    reg = np.sign(np.sin(np.arange(n) / rng.uniform(60, 140) + phase))
    r = rng.normal(drift, vol, n) + reg * 0.0007
    c = (start or rng.uniform(80, 3000)) * np.exp(np.cumsum(r))
    o = np.r_[c[0], c[:-1]] * (1 + rng.normal(0, 0.003, n))
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.007, n)))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.007, n)))
    v = rng.integers(800_000, 6_000_000, n) * (1 + (np.abs(r) > 0.022) * rng.uniform(0.8, 2.2, n))
    idx = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=n)
    if sym.startswith("^"):
        v = np.zeros(n)
    return pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c, "Volume": v}, index=idx)


def fake_download(tickers, period="1mo", interval="1d", group_by="column", threads=True, **kw):
    tickers = [tickers] if isinstance(tickers, str) else list(tickers)
    bad = {"TATAMOTORS.NS", "LODHA.NS"}  # pretend a couple of symbols are missing
    frames = {t: _daily(t) for t in tickers if t not in bad}
    if period.endswith("d"):
        frames = {k: v.tail(int(period[:-1])) for k, v in frames.items()}
    elif period == "6mo":
        frames = {k: v.tail(126) for k, v in frames.items()}
    if not frames:
        return pd.DataFrame()
    if group_by == "ticker":
        return pd.concat(frames, axis=1)
    out = pd.concat(frames, axis=1).swaplevel(axis=1).sort_index(axis=1)
    return out


def fake_history(symbol, period="1y", interval="1d", **kw):
    if symbol.startswith("ZZZ"):
        return pd.DataFrame()
    d = _daily(symbol, 1300)
    if interval in ("15m", "60m"):
        days = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=12 if interval == "60m" else 5)
        step = "60min" if interval == "60m" else "15min"
        stamps = []
        for day in days:
            stamps += list(pd.date_range(day + pd.Timedelta(hours=9, minutes=15), day + pd.Timedelta(hours=15, minutes=15), freq=step))
        rng = np.random.default_rng(_seed(symbol + interval))
        c = d.Close.iloc[-1] * np.exp(np.cumsum(rng.normal(0, 0.003, len(stamps))))
        o = np.r_[c[0], c[:-1]]
        h = np.maximum(o, c) * 1.002
        l = np.minimum(o, c) * 0.998
        df = pd.DataFrame({"Open": o, "High": h, "Low": l, "Close": c, "Volume": rng.integers(10_000, 90_000, len(stamps))}, index=pd.DatetimeIndex(stamps).tz_localize("Asia/Kolkata"))
        return df
    if interval == "1wk":
        d = d.resample("W-FRI").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}).dropna()
    elif interval == "1mo":
        d = d.resample("MS").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}).dropna()
    n = {"5d": 5, "1y": 252, "2y": 504, "5y": 1300, "3y": 780}.get(period, len(d))
    d = d.tail(n if interval == "1d" else max(n // 5, 30))
    d.index = d.index.tz_localize("Asia/Kolkata")
    return d


class FakeTicker:
    def __init__(self, s):
        self.s = s
        self.info = {"shortName": s.replace(".NS", "") + " Ltd", "sector": "Industrials", "trailingPE": 24.5, "priceToBook": 3.1,
                     "returnOnEquity": 0.16, "debtToEquity": 41.0, "marketCap": 1.2e12}

    def history(self, **kw):
        return fake_history(self.s, **kw)


MF_NAMES = {}


def fake_mf_search(q):
    words = q.split()
    if not words or "zzzz" in q.lower():
        return []
    base = " ".join(w.capitalize() for w in words)
    out = []
    for i, suffix in enumerate(["Fund - Direct Plan - Growth Option", "Fund - Regular Plan - IDCW", "Fund - Direct Plan - IDCW Payout"]):
        code = 100000 + _seed(q + suffix) % 90000
        out.append((code, f"{base} {suffix}"))
        MF_NAMES[code] = f"{base} {suffix}"
    return out


def fake_mf_nav3(code):
    n = 1500
    rng = np.random.default_rng(code)
    r = rng.normal(0.0004, 0.009, n) + np.sign(np.sin(np.arange(n) / 90 + code % 7)) * 0.0004
    nav = 50 * np.exp(np.cumsum(r))
    idx = pd.bdate_range(end=pd.Timestamp.now().normalize() - pd.Timedelta(days=1), periods=n)
    return "Equity Scheme - Flexi Cap Fund", pd.Series(nav, index=idx), MF_NAMES.get(code, f"Scheme {code} Direct Growth")


class FakeFeed:
    entries = []


def fake_parse(url):
    class E(dict):
        __getattr__ = dict.get
    f = FakeFeed()
    titles = ["Sensex surges as IT stocks rally on strong earnings and FII inflow", "RBI warns of banking sector NPA risk; lenders fall",
              "Crude oil slump hits ONGC; paint and aviation stocks gain", "Steel makers see weak demand, Tata Steel downgrade",
              "Auto sales record growth in festive season; Maruti, M&M jump"]
    f.entries = [E(title=t, link="https://example.com/" + str(i), source={"title": "MockWire"}, published="Mon, 16 Nov 2026 10:00:00 GMT") for i, t in enumerate(titles)]
    return f


FF_EVENTS = [
    {"title": "Federal Funds Rate", "country": "USD", "date": "2026-11-18T14:00:00-05:00", "impact": "High", "forecast": "3.75%", "previous": "4.00%"},
    {"title": "FOMC Member Powell Speaks", "country": "USD", "date": "2026-11-17T10:00:00-05:00", "impact": "High", "forecast": "", "previous": ""},
    {"title": "CPI m/m", "country": "USD", "date": "2026-11-17T08:30:00-05:00", "impact": "High", "forecast": "0.4%", "previous": "0.3%"},
    {"title": "Unemployment Claims", "country": "USD", "date": "2026-11-19T08:30:00-05:00", "impact": "Medium", "forecast": "215K", "previous": "220K"},
    {"title": "Manufacturing PMI", "country": "CNY", "date": "2026-11-20T21:30:00+08:00", "impact": "Medium", "forecast": "50.2", "previous": "49.8"},
    {"title": "BOJ Policy Rate", "country": "JPY", "date": "2026-11-19T03:00:00+09:00", "impact": "High", "forecast": "0.75%", "previous": "0.50%"},
    {"title": "Crude Oil Inventories", "country": "USD", "date": "2026-11-18T10:30:00-05:00", "impact": "Medium", "forecast": "1.2M", "previous": "-0.8M"},
    {"title": "Bank Holiday", "country": "GBP", "date": "2026-11-20T00:00:00-05:00", "impact": "Holiday", "forecast": "", "previous": ""},
]


class _Resp:
    def __init__(self, text, status=200):
        self.text, self.status_code = text, status

    def json(self):
        return json.loads(self.text)


def fake_http_get(url, **kw):
    if "faireconomy" in url:
        return _Resp(json.dumps(FF_EVENTS))
    raise ConnectionError("offline (mock)")


def install(ff=True):
    D._yf_download = fake_download
    D._yf_history = fake_history
    yf.Ticker = FakeTicker
    D._mf_search_raw = fake_mf_search
    D._mf_nav_raw3 = fake_mf_nav3
    D.nse_api = lambda path: (_ for _ in ()).throw(ConnectionError("offline (mock)"))
    D.feedparser.parse = fake_parse
    D._http_get = fake_http_get if ff else (lambda url, **kw: (_ for _ in ()).throw(ConnectionError("offline")))
